%% ***************************************************************
%           Auther��Jiangyao Luo
%           Email:landiljy@163.com
%           Start date��2019.11.20
%           Finish date��2019.11.20
%           Function description��The way of unit division
%% ***************************************************************
function [ui,uiNumber,allUnitIndex  ] = UnitDivision( N,unitDivisionType )
    if N == 5 
        if unitDivisionType == 1
            ui{1} = [1,3]';
            ui{2} = [2,4,5]';
            uiNumber{1} = [1];
            uiNumber{2} = [3];
            uiNumber{3} = [6];
        elseif unitDivisionType == 2
            ui{1} = [1,3]';
            ui{2} = [2,5]';
            ui{3} = [4]';
            uiNumber{1} = [1];
            uiNumber{2} = [3];
            uiNumber{3} = [5];
            uiNumber{4} = [6];
        else
            ui{1} = [1,2,3,4,5]';
            uiNumber{1} = [1];
            uiNumber{2} = [6];
        end
    elseif N == 28 
        if unitDivisionType == 1
            ui{1} = [1:14]';
            ui{2} = [15:28]';
            uiNumber{1} = [1];
            uiNumber{2} = [15];
            uiNumber{3} = [29];
        elseif unitDivisionType == 2
            ui{1} = [1:28]';
            uiNumber{1} = [1];
            uiNumber{2} = [29];
        else
            ui{1} = 1;
            ui{2} = 2;
            ui{3} = 3;
            ui{4} = 4;
            ui{5} = 5;
            ui{6} = 6;
            ui{7} = 7;
            ui{8} = 8;
            ui{9} = 9;
            ui{10} = 10;
            ui{11} = 11;
            ui{12} = 12;
            ui{13} = 13;
            ui{14} = 14;
            ui{15} = 15;
            ui{16} = 16;
            ui{17} = 17;
            ui{18} = 18;
            ui{19} = 19;
            ui{20} = 20;
            ui{21} = 21;
            ui{22} = 22;
            ui{23} = 23;
            ui{24} = 24;
            ui{25} = 25;
            ui{26} = 26;
            ui{27} = 27;
            ui{28} = 28;
            uiNumber{1} = 1;
            uiNumber{2} = 2;
            uiNumber{3} = 3;
            uiNumber{4} = 4;
            uiNumber{5} = 5;
            uiNumber{6} = 6;
            uiNumber{7} = 7;
            uiNumber{8} = 8;
            uiNumber{9} = 9;
            uiNumber{10} = 10;
            uiNumber{11} = 11;
            uiNumber{12} = 12;
            uiNumber{13} = 13;
            uiNumber{14} = 14;
            uiNumber{15} = 15;
            uiNumber{16} = 16;
            uiNumber{17} = 17;
            uiNumber{18} = 18;
            uiNumber{19} = 19;
            uiNumber{20} = 20;
            uiNumber{21} = 21;
            uiNumber{22} = 22;
            uiNumber{23} = 23;
            uiNumber{24} = 24;
            uiNumber{25} = 25;
            uiNumber{26} = 26;
            uiNumber{27} = 27;
            uiNumber{28} = 28;
            uiNumber{29} = 29;
        end
    elseif N == 35 
        if unitDivisionType == 1
            ui{1} = [1:20]';
            ui{2} = [21:35]';
            uiNumber{1} = [1];
            uiNumber{2} = [21];
            uiNumber{3} = [36];
        else
            
        end
    else
        
    end

    allUnitIndex = [];    %
    for i = 1:size(ui,2)
        allUnitIndex = [allUnitIndex; ui{i}];
    end

end

