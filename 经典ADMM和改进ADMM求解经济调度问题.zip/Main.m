%% ***************************************************************
%           Auther��Jiangyao Luo
%           Email:landiljy@163.com
%           Start date��2019.11.20
%           Finish date��2019.11.23
%           Function description��Comparing classical ADMM and improved ADMM to
%                                 solve economic dispatch (ED) problem
%% ***************************************************************
function [  ] = Main(  )
    
%----------------------------------------Console---------------start-----------------------------------------%
%     filenamePath = 'UC_AF/5_std.mod';
    filenamePath='UC_AF/c1_28_based_8_std.mod';
%     filenamePath='UC_AF/c2_35_based_8_std.mod';
    display = 'yes';    %Choose "yes" or "no". "yes" means displaying the process; otherwise,don't display the process
    epsilonAbs = 1e-3;  %Absolute tolerance  
    epsilonRel = 1e-2;  %Relative tolerance
    isRecordResult = 'yes'; %Choose "yes" and "no". "yes" means recording the result; otherwise, don's record the result.
    filePath = 'F:\MATLAB2014\WorkSpace\CompareADMMwith1and2norm\Result';   %File savepath.
    useImproved = 'yes';    %Choose "yes" or "no".  "yes" means using the improved method; otherwise, don't use the improved method.
    startGamma = 0.1;  %Gamma is used in improved ADMM, and its value range is the open interval between 0 and 2.
    addGamma = 0.05;
    endGamma = 1.9;
    unitDivisionType = 1;   %Different way of unit division
    startRou = 0.01;    %Penalty parameter.
    addRou = 0.01;
    endRou = 0.3;
    admmMaxIteration = 200; %The max iteration of ADMM.
%-----------------------------------------Console-----------------end----------------------------------------%
    
    %Read ED data.
    dataED = ReadataED(filenamePath); 
    
    %Constant
    N = dataED.baseParameter.unitNumber;    %The total unit number.
    T = dataED.baseParameter.timeInterval;  %The total time interval.
    
    %Unit partition
    [ui,uiNumber,allUnitIndex ] = UnitDivision(N,unitDivisionType);
    
    %Construct coefficient matrix of constraint, lower bound of variable and up bound of variable.
    [ A_wan,b_A_wan,A_ii,b_A_ii,lb_ii,ub_ii] = FormMatrix( N,T,ui,dataED );
    
    %Construct coefficient matrix of objective function
    [ H_ii,f_ii,c_ii ] = FormObjFunMatrix( N,T,ui,dataED );
    
    %Construct edProblem
    edProblem.A_wan = A_wan;
    edProblem.b_A_wan = b_A_wan;
    edProblem.A_ii = A_ii;
    edProblem.b_A_ii = b_A_ii;
    edProblem.lb_ii = lb_ii;
    edProblem.ub_ii = ub_ii;
    edProblem.H_ii = H_ii;
    edProblem.f_ii = f_ii;
    edProblem.c_ii = c_ii;
    
    %Using commericial slover Cplex to solve the ED problem
    [ funCplex,solveTimeCplex,tolCplex ] = CplexSolveED( edProblem,N,T,ui,uiNumber );
    
%------------------------------------------------Classical ADMM-----------------start-------------------------------------%
    if isequal(isRecordResult,'yes')
        filePath1 = strcat(filePath,'\ClassicalADMM.txt');
        fp = fopen(filePath1,'a');
        fprintf(fp,'%s\t%s\t%s\t%s\t%s\t\r\n','������','ADMM����','ADMM����ֵ','ADMMʱ��','Cplex���Ž�');
    end
    for rou = startRou:addRou:endRou
        x_k = zeros(N,T);   %
        z_k = zeros(N,T);   %
        u_k = zeros(N,T);   %
        funADMM2 = 0;   %
        iterationADMM2= 0;  %
        n = size(ui,2); %The number of area.

        %Table header
        if isequal(display,'yes')
            fprintf('%s%s%s%s%s%s\n','iteration |',' Primal residual |',' Absolute criterion |'...
                    ,' Dual residual |',' Relative criterion |',' Objective function |');
        end

        %Timing starts
        tic 
        for iter = 1:admmMaxIteration
            %x update step
            for iIndex = 1:n
                %Using commericial slover Cplex to solve x update subproblem
                x_k(uiNumber{iIndex}:uiNumber{iIndex+1}-1,:) = SolveXiSubProblem( edProblem,z_k,u_k,T,uiNumber,iIndex,rou );
            end

            %z update step
            z_k_old = z_k;
            z_k = SolveZiSubProblem( edProblem,x_k,u_k,rou,N,T );

            %u update step
            u_k = u_k + x_k - z_k;

            %The value of objective function calculated in iteration
            funADMM2 = 0;
            x_k_reform = reshape(x_k',N * T,1);
            H_ii_reform = [];
            f_ii_reform = zeros(N * T,1);
            c_ii_reform = zeros(N * T,1);
            for iIndex = 1:n
                H_ii_reform = blkdiag(H_ii_reform,edProblem.H_ii{iIndex});
                f_ii_reform(1 + (uiNumber{iIndex}-1)*T:(uiNumber{iIndex+1} - 1) * T,1) = edProblem.f_ii{iIndex};
                c_ii_reform(1 + (uiNumber{iIndex}-1)*T:(uiNumber{iIndex+1} - 1) * T,1) = edProblem.c_ii{iIndex};
            end
            funADMM2 = funADMM2 + 1/2 * x_k_reform' * H_ii_reform * x_k_reform + f_ii_reform' * x_k_reform + sum(c_ii_reform);
            history.funADMM(iter,1) = funADMM2;

            %primal residual
            history.rNorm(iter,1) = norm(x_k - z_k);

            %dual residual
            history.sNorm(iter,1) = norm(rou * (z_k - z_k_old));

            %absolute criterion
            %'fro' to calculate the frobenius norm of the sparse matrix
            history.eps_pri(iter,1) = sqrt(N*T) * epsilonAbs + epsilonRel * max(norm(x_k,'fro'),norm(-z_k,'fro'));

            %relative criterion
            history.eps_dual(iter,1) = sqrt(N*T) * epsilonAbs + epsilonRel * norm( rou*u_k);

            %Display the process
            if isequal(display,'yes')
                fprintf('%s%3d\t%s%10.4f\t%s%10.4f\t%s%10.4f\t%s%10.4f\t%s%10.2f%s\n','  ', iter,'  |   ', ...
                    history.rNorm(iter),'|    ', history.eps_pri(iter),'     | ', ...
                    history.sNorm(iter),' |   ', history.eps_dual(iter),'      |     ', history.funADMM(iter),'     |');
            end

            %stopping criterion
            if (history.rNorm(iter) < history.eps_pri(iter) && history.sNorm(iter) < history.eps_dual(iter)) 
                iterationADMM2 = iter;
                break;
            elseif isequal(iter,admmMaxIteration)
                iterationADMM2 = iter;
                break;
            end
        end
        %Timing end
        timeADMM2 = toc; 

        %Display the process
        if isequal(display,'yes')
            disp('---------------------------Cplex & Classical ADMM-----start-------------------------------------------');
            fprintf('Filename: %s\n',filenamePath);
            fprintf('The objval calculated by Cplex: %f\n', funCplex);
            fprintf('Cpu time of Cplex: %f%s\n', solveTimeCplex,'��');
            disp('       ---------------------------Classical ADMM---------------------------------------------');
            fprintf('Absolute tolerance: %f\n',epsilonAbs);
            fprintf('Relative tolerancer: %f\n',epsilonRel);
            fprintf('Penalty parameter of ADMM: %f\n',rou);
            fprintf('The objval calculated by ADMM: %f\n', funADMM2);
            fprintf('The relative gap between ADMM and Cplex: %e\n', abs(funADMM2 - funCplex)/funCplex);
            fprintf('Number of iteration for ADMM:%3d%s\n', iterationADMM2,'��');
            fprintf('Cpu time of ADMM = %f%s\n', timeADMM2,'��');
            disp('--------------------------Cplex & Classical ADMM-----end----------------------------------------------');
        end
        %Save the result to the file.
        if isequal(isRecordResult,'yes')
            fp = fopen(filePath1,'a');
            fprintf(fp,'%s\t%s\t\t%s\t%s\t\t%s\t\r\n',num2str(rou),num2str(iterationADMM2)...
                    ,num2str(funADMM2),num2str(timeADMM2),num2str(funCplex));
            fclose(fp);
        end
    end
%------------------------------------------Classical ADMM--------------------end--------------------------------------------%

%------------------------------------------------Improved ADMM---------------------------start-----------------------------%
    if isequal(useImproved,'yes')
        filePath2 = strcat(filePath,'\ImprovedADMM.txt');
        if isequal(isRecordResult,'yes')
            fp = fopen(filePath2,'a');
            fprintf(fp,'%s\t%s\t%s\t%s\t%s\t%s\t\r\n','������','Gamma','ADMM����','ADMM����ֵ','ADMMʱ��','Cplex���Ž�');
        end
        for rou = startRou:addRou:endRou
            for gamma = startGamma:addGamma:endGamma
                x_k = zeros(N,T);   %
                z_k = zeros(N,T);   %
                u_k = zeros(N,T);   %
                funADMM2 = 0;   %
                iterationADMM2= 0;  %
                n = size(ui,2); %The number of area.

                %Table header
                if isequal(display,'yes')
                    fprintf('%s%s%s%s%s%s\n','iteration |',' Primal residual |',' Absolute criterion |'...
                            ,' Dual residual |',' Relative criterion |',' Objective function |');
                end

                %Timing starts
                tic 
                for iter = 1:admmMaxIteration
                    %x update step
                    for iIndex = 1:n
                        %Using commericial slover Cplex to solve x update subproblem
                        x_k(uiNumber{iIndex}:uiNumber{iIndex+1}-1,:) = SolveXiSubProblem( edProblem,z_k,u_k,T,uiNumber,iIndex,rou );
                    end

                    %Generate forecast points
                    u_k_old = u_k;
                    z_k_old = z_k;
                    u_k = u_k + x_k - z_k;
                    z_k = SolveZiSubProblem( edProblem,x_k,u_k,rou,N,T );

                    %Relaxation continuation
                    %z update step
                    z_k = z_k_old - gamma * (z_k_old - z_k);
                    %u update step
                    u_k = u_k_old - gamma * (u_k_old - u_k);

                    %The value of objective function calculated in iteration
                    funADMM2 = 0;
                    x_k_reform = reshape(x_k',N * T,1);
                    H_ii_reform = [];
                    f_ii_reform = zeros(N * T,1);
                    c_ii_reform = zeros(N * T,1);
                    for iIndex = 1:n
                        H_ii_reform = blkdiag(H_ii_reform,edProblem.H_ii{iIndex});
                        f_ii_reform(1 + (uiNumber{iIndex}-1)*T:(uiNumber{iIndex+1} - 1) * T,1) = edProblem.f_ii{iIndex};
                        c_ii_reform(1 + (uiNumber{iIndex}-1)*T:(uiNumber{iIndex+1} - 1) * T,1) = edProblem.c_ii{iIndex};
                    end
                    funADMM2 = funADMM2 + 1/2 * x_k_reform' * H_ii_reform * x_k_reform + f_ii_reform' * x_k_reform + sum(c_ii_reform);
                    history.funADMM(iter,1) = funADMM2;

                    %primal residual
                    history.rNorm(iter,1) = norm(x_k - z_k);

                    %dual residual
                    history.sNorm(iter,1) = norm(rou * (z_k - z_k_old));

                    %absolute criterion
                    %'fro' to calculate the frobenius norm of the sparse matrix
                    history.eps_pri(iter,1) = sqrt(N*T) * epsilonAbs + epsilonRel * max(norm(x_k,'fro'),norm(-z_k,'fro'));

                    %relative criterion
                    history.eps_dual(iter,1) = sqrt(N*T) * epsilonAbs + epsilonRel * norm( rou*u_k);

                    %Display the process
                    if isequal(display,'yes')
                        fprintf('%s%3d\t%s%10.4f\t%s%10.4f\t%s%10.4f\t%s%10.4f\t%s%10.2f%s\n','  ', iter,'  |   ', ...
                            history.rNorm(iter),'|    ', history.eps_pri(iter),'     | ', ...
                            history.sNorm(iter),' |   ', history.eps_dual(iter),'      |     ', history.funADMM(iter),'     |');
                    end

                    %stopping criterion
                    if (history.rNorm(iter) < history.eps_pri(iter) && history.sNorm(iter) < history.eps_dual(iter)) 
                        iterationADMM2 = iter;
                        break;
                    elseif isequal(iter,admmMaxIteration)
                        iterationADMM2 = iter;
                        break;
                    end
                end
                %Timing end
                timeADMM2 = toc; 
                %Display the process
                if isequal(display,'yes')
                    disp('---------------------------Cplex & Improved ADMM-----start-------------------------------------------');
                    fprintf('Filename: %s\n',filenamePath);
                    fprintf('The objval calculated by Cplex: %f\n', funCplex);
                    fprintf('Cpu time of Cplex: %f%s\n', solveTimeCplex,'��');
                    disp('       ---------------------------Improved ADMM---------------------------------------------');
                    fprintf('Absolute tolerance: %f\n',epsilonAbs);
                    fprintf('Relative tolerancer: %f\n',epsilonRel);
                    fprintf('Penalty parameter of ADMM: %f\n',rou);
                    fprintf('The objval calculated by ADMM: %f\n', funADMM2);
                    fprintf('The relative gap between ADMM and Cplex: %e\n', abs(funADMM2 - funCplex)/funCplex);
                    fprintf('Number of iteration for ADMM:%3d%s\n', iterationADMM2,'��');
                    fprintf('Cpu time of ADMM = %f%s\n', timeADMM2,'��');
                    disp('--------------------------Cplex & Improved ADMM-----end----------------------------------------------');
                end
                %Save the result to the file.
                if isequal(isRecordResult,'yes')
                    fp = fopen(filePath2,'a');
                    fprintf(fp,'%s\t%s\t%s\t\t%s\t%s\t\t%s\t\r\n',num2str(rou),num2str(gamma),num2str(iterationADMM2)...
                            ,num2str(funADMM2),num2str(timeADMM2),num2str(funCplex));
                    fclose(fp);
                end
            end
        end
    end
%------------------------------------------------Improved ADMM------------------------end-------------------------------%

   
end

