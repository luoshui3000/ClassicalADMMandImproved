%% ***************************************************************
%           Auther��ljy
%           Email:landiljy@163.com
%           Start date��2019.11.20
%           Finish date��2019.11.20
%           Function description��Read economic dispatch data
%% ***************************************************************
function dataED=ReadataED(filenamePath)
fprintf('\n\n\n');
disp('------------------------��ȡ���õ������������ļ�----------------------------');
disp('------------------------Read economic dispatch data----------------------------');

    dataED.filenamePath = filenamePath;
    fid=fopen(filenamePath);
    %Ignore ProblemNum.
    fgetl(fid);
%-------------------dataED.baseParameter---------start--------------------%
    %Total time interval.
    tmp=fscanf(fid,'%s',1);                     
    dataED.baseParameter.timeInterval = fscanf(fid,'%d',1);  
    %Total number of unit.
    tmp=fscanf(fid,'%s',1);                     
    dataED.baseParameter.unitNumber = fscanf(fid,'%d',1);
%-------------------dataED.baseParameter---------end----------------------%
    %Ignore NumHydro,NumCascade,LoadCurve,MinSystemCapacity,MaxSystemCapacity,MaxThermalCapacity,Loads
    fgetl(fid);  % ��һ�еĽ�β
    for i = 1:7 
      fgetl(fid); 
    end
    
%---------------------dataED.totalLoad----------------start----------------%
    %System load demand.
    dataED.totalLoad.powerDemand = fscanf(fid,'%f',[1,dataED.baseParameter.timeInterval]);
    dataED.totalLoad.powerDemand = dataED.totalLoad.powerDemand';
    %Ignore 
    fgetl(fid);
    fgetl(fid);
    %Spin.
    dataED.totalLoad.spin = fscanf(fid,'%f',[1,dataED.baseParameter.timeInterval]);
    dataED.totalLoad.spin = dataED.totalLoad.spin';
    %Ignore 
    fgetl(fid);
    fgetl(fid);
%---------------------dataED.totalLoad------------------end----------------% 

%---------------------dataED.unitInfo----------------start-----------------%
    dataED.unitInfo.unitIndex = zeros(dataED.baseParameter.unitNumber,1);
    for iIndex = 1:dataED.baseParameter.unitNumber
        if size(strfind(dataED.filenamePath,'_std.mod') ,1) ~= 0
            unitParameter(iIndex,:) = fscanf(fid,'%f',[1,17]);     
        else
            unitParameter(iIndex,:) = fscanf(fid,'%f',[1,16]);
        end
        fscanf(fid,'%s',1);
        %Index for unit. 
        dataED.unitInfo.unitIndex(iIndex) = iIndex;
        %Ramp up limit of unit.
        dataED.unitInfo.rampUp(iIndex) = fscanf(fid,'%f',1);
        %Ramp down limit of unit.
        dataED.unitInfo.rampDown(iIndex) = fscanf(fid,'%f',1);
    end
    %Ignore
    fgetl(fid);
    fgetl(fid);
    fgetl(fid);
    dataED.unitInfo.rampUp = dataED.unitInfo.rampUp';
    dataED.unitInfo.rampDown = dataED.unitInfo.rampDown';
    
    %The constant term in unit cost function
    dataED.unitInfo.alpha = unitParameter(:,4);
    %The coefficient of primary term in unit cost function
    dataED.unitInfo.beta = unitParameter(:,3);
    %The coefficient of quadratic term in unit cost function
    dataED.unitInfo.gamma = unitParameter(:,2);
    %Minimum power output of unit.
    dataED.unitInfo.lowerOutput = unitParameter(:,5);
    %Maximum power output of unit.
    dataED.unitInfo.upOutput = unitParameter(:,6);
    %Initial power output of unit.
    dataED.unitInfo.initialOutput = 0.7 * unitParameter(:,6);
    
    
%---------------------dataED.unitInfo------------------end-----------------%

%----------------------xxxxxx8_std.mod-----------------start---------------%
    if size(strfind(dataED.filenamePath,'8_std.mod') ,1) ~= 0
        dataED.totalLoad.powerDemand = sum(dataED.unitInfo.upOutput) * [0.71; 0.65; 0.62;  0.6;  0.58;  0.58;  0.6;  0.64;
                                        0.73; 0.8;  0.82;  0.83;   0.82; 0.8;  0.79;  0.79;
                                        0.83; 0.91; 0.9;  0.88;   0.85;  0.84;  0.79;  0.74];

    end
%----------------------xxxxxx8_std.mod-----------------end-----------------%
fclose(fid);



