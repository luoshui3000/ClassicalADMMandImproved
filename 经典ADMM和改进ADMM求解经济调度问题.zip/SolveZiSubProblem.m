%% ***************************************************************
%           Auther��Jiangyao Luo
%           Email:landiljy@163.com
%           Start date��2019.11.22
%           Finish date��2019.11.22
%           Function description��Using commericial slover Cplex to solve z
%                                 update subproblem 
%% ***************************************************************
function [ z_k ] = SolveZiSubProblem( edProblem,x_k,u_k,rou,N,T )
    
    Aeq = edProblem.A_wan;
    beq = edProblem.b_A_wan;
    lb = -inf * ones(N * T,1);
    ub = inf * ones(N * T,1); 
    H = sparse(1:N * T,1:N * T,rou);
    f = -rou*reshape((x_k + u_k)',N * T,1);

    options = cplexoptimset;
    options.Display = 'off';
    [z_k] = cplexqp(H,f,[],[],Aeq,beq,lb,ub,[],options);
    z_k = reshape(z_k,T,N)';

    
end

