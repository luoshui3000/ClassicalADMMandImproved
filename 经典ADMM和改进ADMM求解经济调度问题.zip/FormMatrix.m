%% ***************************************************************
%           Auther��Jiangyao Luo
%           Email:landiljy@163.com
%           Start date��2019.11.20
%           Finish date��2019.11.20
%           Function description��Construct coefficient matrix of constraint
%                                 ,lower bound of variable and up bound of variable.
%% ***************************************************************
function [ A_wan,b_A_wan,A_ii,b_A_ii,lb_ii,ub_ii] = FormMatrix( N,T,ui,dataED )
    
    n = size(ui,2); %The number of area.
    
%------------Construction of A_ii and b_A_ii-------------start-------------%
    A_ii = cell(1,n);   %The coefficient matrix.
    b_A_ii = cell(1,n); %The constant vector.
    
    %The coefficient of ramp up/down. 
    up = diag(-1.*ones(T-1,1));
    up = [up,zeros(T-1,1)] + [zeros(T-1,1),-1*up];
    down = -up;
    
    for iIndex = 1:n
        columnIndexSet = ui{iIndex}; %
        unitiIndexNumber = size(columnIndexSet,1);
        A_ii{iIndex} = zeros(2 * unitiIndexNumber * T,unitiIndexNumber * T);
        b_A_ii{iIndex} = zeros(2 * unitiIndexNumber * T,1);
%         A_ii{iIndex} = zeros(2 * unitiIndexNumber * (T - 1),unitiIndexNumber * T);
%         b_A_ii{iIndex} = zeros(2 * unitiIndexNumber * (T - 1),1);
        
        for jIndex = 1:unitiIndexNumber
            %Ramp up
            %P_1-P_0<=P_rampup
            A_ii{iIndex}(1 + 2 * (jIndex-1) * T,1 + (jIndex-1) * T) = 1;
            b_A_ii{iIndex}(1 + 2 * (jIndex-1) * T,1) = dataED.unitInfo.initialOutput(columnIndexSet(jIndex,1),1) + dataED.unitInfo.rampUp(columnIndexSet(jIndex,1),1);
            %P_k+1-P_k<=P_rampup
            A_ii{iIndex}(2 + 2 * (jIndex-1) * T:2 * (jIndex-1) * T+ T,1 + (jIndex-1) * T :jIndex * T) = up;
            b_A_ii{iIndex}(2 + 2 * (jIndex-1) * T:2 * (jIndex-1) * T+ T,1) = dataED.unitInfo.rampUp(columnIndexSet(jIndex,1),1);
            %Ramp down
            %P_0-P_1<=P_rampdown
            A_ii{iIndex}(2 * (jIndex-1) * T+ T + 1,1 + (jIndex-1) * T) = -1;
            b_A_ii{iIndex}(2 * (jIndex-1) * T+ T + 1,1) = dataED.unitInfo.rampDown(columnIndexSet(jIndex,1),1) - dataED.unitInfo.initialOutput(columnIndexSet(jIndex,1),1);
            %P_k-P_k+1<=P_rampdown
            A_ii{iIndex}(2 * (jIndex-1) * T+ T + 2:2*(jIndex-1) * T+ 2 * T,1 + (jIndex-1) * T:jIndex * T) = down;
            b_A_ii{iIndex}(2 * (jIndex-1) * T+ T + 2:2*(jIndex-1) * T+ 2 * T,1) = dataED.unitInfo.rampDown(columnIndexSet(jIndex,1),1);
        end
        
    end 
%------------Construction of A_ii and b_A_ii-------------end---------------%

%------------Construction of A_wan and b_A_wan---------------start---------%
    A_wan = zeros(T,N * T); %The coefficient matrix.
    b_A_wan = dataED.totalLoad.powerDemand; %The constant vector.
    %The coefficient of system power demand.
    pdCoefficient = [repmat([1,zeros(1,T-1)],1,N-1),1];
    
    for iIndex = 1:T
        %System power demand.
        A_wan(iIndex,iIndex:iIndex + (N-1)*T) = pdCoefficient;
    end
%------------Construction of A_wan and b_A_wan---------------end-----------%

%----------------------Construction of lb_ii and ub_ii-------start--------%
    lb_ii = cell(1,n);  %Lower bound of variable.
    ub_ii = cell(1,n);  %Upper bound of variable.
    
    for iIndex = 1:n
        columnIndexSet = ui{iIndex}; %
        unitiIndexNumber = size(columnIndexSet,1);
        lb_ii{iIndex} = zeros(T * unitiIndexNumber,1);
        ub_ii{iIndex} = zeros(T * unitiIndexNumber,1);
        
        for jIndex = 1:unitiIndexNumber
            %Minimun power output.
            lb_ii{iIndex}(1 + T * (jIndex-1):jIndex * T,1) = dataED.unitInfo.lowerOutput(columnIndexSet(jIndex,1),1);
            %Maximum power output.
            ub_ii{iIndex}(1 + T * (jIndex-1):jIndex * T,1) = dataED.unitInfo.upOutput(columnIndexSet(jIndex,1),1);
        end
    end
%----------------------Construction of lb_ii and ub_ii-------start--------%

end

