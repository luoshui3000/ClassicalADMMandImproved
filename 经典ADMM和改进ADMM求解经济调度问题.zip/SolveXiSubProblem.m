%% ***************************************************************
%           Auther��Jiangyao Luo
%           Email:landiljy@163.com
%           Start date��2019.11.22
%           Finish date��2019.11.22
%           Function description��Using commericial slover Cplex to solve x
%                                 update subproblem 
%% ***************************************************************
function [ x_ki ] = SolveXiSubProblem( edProblem,z_k,u_k,T,uiNumber,iIndex,rou )


    H = edProblem.H_ii{iIndex} + full(sparse(1:(uiNumber{iIndex+1} - uiNumber{iIndex}) * T,1:(uiNumber{iIndex+1} - uiNumber{iIndex}) * T,rou));
    f = edProblem.f_ii{iIndex} + reshape(rou * (u_k(uiNumber{iIndex}:uiNumber{iIndex+1}-1,:) ...
        - z_k(uiNumber{iIndex}:uiNumber{iIndex+1}-1,:))',(uiNumber{iIndex+1} - uiNumber{iIndex}) * T,1);
    Aineq = edProblem.A_ii{iIndex};
    bineq = edProblem.b_A_ii{iIndex};
    lb = edProblem.lb_ii{iIndex};
    ub = edProblem.ub_ii{iIndex};
    
    options = cplexoptimset;
    options.Display = 'off';
    [x_ki] = cplexqp(H,f,Aineq,bineq,[],[],lb,ub,[],options);
    x_ki = reshape(x_ki,T,uiNumber{iIndex+1} - uiNumber{iIndex})';
    
end

