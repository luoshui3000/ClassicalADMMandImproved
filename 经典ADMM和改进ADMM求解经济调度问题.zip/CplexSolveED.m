%% ***************************************************************
%           Auther��Jiangyao Luo
%           Email:landiljy@163.com
%           Start date��2019.11.22
%           Finish date��2019.11.22
%           Function description��Using commericial slover Cplex to solve ED
%                                 problem
%% ***************************************************************
function [ funCplex,solveTimeCplex,tolCplex ] = CplexSolveED( edProblem,N,T,ui,uiNumber )
    n = size(ui,2); %The number of area.
    A_wan = edProblem.A_wan;
    b_A_wan = edProblem.b_A_wan;
    A_ii = edProblem.A_ii;
    b_A_ii = edProblem.b_A_ii;
    lb_ii = edProblem.lb_ii;
    ub_ii = edProblem.ub_ii;
    H_ii = edProblem.H_ii;
    f_ii = edProblem.f_ii;
    c_ii = edProblem.c_ii;
    H = [];
    f = zeros(N * T,1);
    Aineq = [];
    bineq = zeros(2 * N * T,1);
    Aeq = A_wan;
    beq = b_A_wan;
    lb = zeros(N * T,1);
    ub = zeros(N * T,1);
    constantTerm = 0;
    
    for iIndex = 1:n
        H = blkdiag(H,H_ii{iIndex});
        f(1 + (uiNumber{iIndex} - 1) * T:(uiNumber{iIndex+1}-1)*T,1) = f_ii{iIndex};
        if isequal(iIndex,1)
            Aineq = [A_ii{iIndex},zeros(size(A_ii{iIndex},1),(uiNumber{n+1} - uiNumber{iIndex + 1}) * T)];
        elseif isequal(iIndex,n)
            Aineq = [Aineq;[zeros(size(A_ii{iIndex},1),(uiNumber{n} - uiNumber{1}) * T),A_ii{iIndex}]];
        else
            Aineq = [Aineq;[zeros(size(A_ii{iIndex},1),(uiNumber{iIndex} - uiNumber{1}) * T),A_ii{iIndex},zeros(size(A_ii{iIndex},1),(uiNumber{n+1} - uiNumber{iIndex+1}) * T)]];
        end
        bineq(1 + 2 * (uiNumber{iIndex} - 1) * T:2 * (uiNumber{iIndex+1}-1)*T,1) = b_A_ii{iIndex};
        lb(1 + (uiNumber{iIndex} - 1) * T:(uiNumber{iIndex+1}-1)*T,1) = lb_ii{iIndex};
        ub(1 + (uiNumber{iIndex} - 1) * T:(uiNumber{iIndex+1}-1)*T,1) = ub_ii{iIndex};
        constantTerm = constantTerm + sum(c_ii{iIndex});
    end
    
    options = cplexoptimset;
    options.Display = 'off';
%     options.TolFun = 1e-5;
    [xCplex,funCplex,exitflag,output,lambda] = cplexqp(H,f,Aineq,bineq,Aeq,beq,lb,ub,[],options);
    tolCplex = options.TolFun;
    solveTimeCplex = output.time;
    funCplex = funCplex + constantTerm;
    
end

