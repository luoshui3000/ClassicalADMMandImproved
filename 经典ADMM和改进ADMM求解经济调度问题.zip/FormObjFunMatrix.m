%% ***************************************************************
%           Auther��Jiangyao Luo
%           Email:landiljy@163.com
%           Start date��2019.11.20
%           Finish date��2019.11.20
%           Function description��Construct coefficient matrix of objective
%                                 function.
%% ***************************************************************
function [ H_ii,f_ii,c_ii ] = FormObjFunMatrix( N,T,ui,dataED )
    n = size(ui,2); %The number of area.
    
    H_ii = cell(1,n);   %The quadratic term.
    f_ii = cell(1,n);   %The primal term.
    c_ii = cell(1,n);   %The constant term.
    
    for iIndex = 1:n
        columnIndexSet = ui{iIndex}; %
        unitiIndexNumber = size(columnIndexSet,1);
        H_ii{iIndex} = [];
        f_ii{iIndex} = zeros(unitiIndexNumber * T,1);
        c_ii{iIndex} = zeros(unitiIndexNumber * T,1);
        
        for jIndex = 1:unitiIndexNumber
            H_ii{iIndex} = blkdiag(H_ii{iIndex},full(sparse(1:T,1:T,2 * dataED.unitInfo.gamma(columnIndexSet(jIndex,1),1))));
            f_ii{iIndex}(1 + (jIndex-1) * T:jIndex * T) = dataED.unitInfo.beta(columnIndexSet(jIndex,1),1);
            c_ii{iIndex}(1 + (jIndex-1) * T:jIndex * T) = dataED.unitInfo.alpha(columnIndexSet(jIndex,1),1);
        end
    end
    
end

